# Databricks notebook source
# MAGIC %md
# MAGIC Final Denormalized view for creating Dashboard

# COMMAND ----------

# Create Denormalized Dashboard View

spark.sql("""
CREATE OR REPLACE VIEW
life_sciences_analytics.gold.vw_commercial_sales_dashboard
AS
SELECT
    -- Date details
    D.Calendar_Date,
    D.Day_Name,
    D.Month_Number,
    D.Month_Name,
    D.Quarter,
    D.Year,

    -- Healthcare Provider details
    H.NPI_Number,
    H.First_Name,
    H.Last_Name,
    H.Specialty,

    -- Healthcare Organization details
    O.Facility_ID,
    O.Facility_Name,
    O.Facility_Type,
    O.City,
    O.State,

    -- Product details
    P.NDC_Code,
    P.Brand_Name,
    P.Dosage_Form,
    P.Strength,
    P.Therapeutic_Class,
    P.WAC_Price,

    -- Sales Representative and territory details
    R.Rep_Employee_ID,
    R.Rep_Name,
    R.Territory_Code,
    R.Region,
    R.Role,

    -- Sales details
    F.Channel_Type,
    F.TRx_Count,
    F.NRx_Count,
    F.Units_Dispensed,
    F.Gross_Sales_Amount,
    F.Rebate_Amount,
    F.Net_Sales_Amount,
    F.Load_Date

FROM life_sciences_analytics.gold.Fact_Daily_Commercial_Sales F

JOIN life_sciences_analytics.gold.Dim_Date D
    ON F.Date_Key = D.Date_Key

JOIN life_sciences_analytics.gold.Dim_HCP H
    ON F.HCP_Key = H.HCP_Key

JOIN life_sciences_analytics.gold.Dim_HCO O
    ON F.HCO_Key = O.HCO_Key

JOIN life_sciences_analytics.gold.Dim_Product P
    ON F.Product_Key = P.Product_Key

JOIN life_sciences_analytics.gold.Dim_Sales_Rep R
    ON F.Rep_Key = R.Rep_Key
""")

# COMMAND ----------

spark.sql("""
SELECT *
FROM life_sciences_analytics.gold.vw_commercial_sales_dashboard
LIMIT 10
""").show(truncate=False)

# COMMAND ----------

