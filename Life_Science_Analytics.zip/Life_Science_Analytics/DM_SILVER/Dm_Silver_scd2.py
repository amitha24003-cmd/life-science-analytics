# Databricks notebook source
# MAGIC %md
# MAGIC SILVER LAYER: DATA VALIDATION

# COMMAND ----------


# Insert new records from Bronze into Silver

spark.sql("""
MERGE INTO life_sciences_analytics.silver.slv_sales_rep T
USING life_sciences_analytics.bronze.src_sales_rep S
ON  T.rep_emp_id = S.rep_emp_id
AND T.effective_date = S.effective_date

WHEN NOT MATCHED THEN
    INSERT (
        rep_emp_id,
        rep_name,
        territory_code,
        region,
        role,
        effective_date,
        Load_Date
    )
    VALUES (
        S.rep_emp_id,
        S.rep_name,
        S.territory_code,
        S.region,
        S.role,
        S.effective_date,
        S.Load_Date
    )
""")

# COMMAND ----------

# MAGIC %md
# MAGIC Validation tests

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 1: Record Count Check
# MAGIC SELECT COUNT(*) AS Target_count
# MAGIC FROM life_sciences_analytics.bronze.src_sales_rep;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS target_count
# MAGIC FROM life_sciences_analytics.silver.slv_sales_rep;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 2: Record Count Check with GROUP BY
# MAGIC SELECT region, COUNT(*) AS record_count
# MAGIC FROM life_sciences_analytics.bronze.src_sales_rep
# MAGIC GROUP BY region
# MAGIC ORDER BY region;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT region, COUNT(*) AS record_count
# MAGIC FROM life_sciences_analytics.silver.slv_sales_rep
# MAGIC GROUP BY region
# MAGIC ORDER BY region;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 3: Random Record Check
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.silver.slv_sales_rep
# MAGIC ORDER BY rep_emp_id, effective_date
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_sales_rep
# MAGIC ORDER BY rep_emp_id, effective_date
# MAGIC LIMIT 5

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 4: Column level check
# MAGIC SELECT COUNT(*) AS mismatch_count
# MAGIC FROM life_sciences_analytics.bronze.src_sales_rep s
# MAGIC LEFT JOIN life_sciences_analytics.silver.slv_sales_rep t
# MAGIC     ON s.rep_emp_id = t.rep_emp_id
# MAGIC    AND s.effective_date = t.effective_date
# MAGIC WHERE t.rep_emp_id IS NULL
# MAGIC    OR NOT (s.rep_name <=> t.rep_name)
# MAGIC    OR NOT (s.territory_code <=> t.territory_code)
# MAGIC    OR NOT (s.region <=> t.region)
# MAGIC    OR NOT (s.role <=> t.role);