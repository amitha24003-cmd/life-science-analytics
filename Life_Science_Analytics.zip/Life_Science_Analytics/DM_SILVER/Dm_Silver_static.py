# Databricks notebook source
# MAGIC %md
# MAGIC Silver layer: Data Validation 

# COMMAND ----------

# MAGIC %md
# MAGIC DATE DIMENSION

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Silver Calendar table from the Bronze source
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.silver.slv_calender
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC     calendar_date,
# MAGIC     day_of_week,
# MAGIC     day_name,
# MAGIC     month_number,
# MAGIC     month_name,
# MAGIC     quarter,
# MAGIC     year,
# MAGIC     is_weekend,
# MAGIC     Load_Date
# MAGIC FROM life_sciences_analytics.bronze.src_calender;

# COMMAND ----------

# MAGIC %sql
# MAGIC --Validation Test
# MAGIC -- TEST 1: ROW COUNT CHECK
# MAGIC SELECT COUNT(*) AS SOURCE_COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_calender;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS TARGET_COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_calender;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 2: Record Count Check with GROUP BY
# MAGIC SELECT month_number, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_calender
# MAGIC GROUP BY month_number
# MAGIC ORDER BY month_number;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT month_number, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_calender
# MAGIC GROUP BY month_number
# MAGIC ORDER BY month_number;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 3: Random Record Check
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_calender
# MAGIC ORDER BY calendar_date
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.silver.slv_calender
# MAGIC ORDER BY calendar_date
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC --Test 4: Column level Check
# MAGIC SELECT COUNT(*) AS mismatch
# MAGIC FROM life_sciences_analytics.silver.slv_calender T
# MAGIC LEFT JOIN life_sciences_analytics.bronze.src_calender S
# MAGIC     ON T.calendar_date = S.calendar_date
# MAGIC WHERE S.calendar_date IS NULL
# MAGIC    OR T.day_of_week <> S.day_of_week
# MAGIC    OR T.day_name <> S.day_name
# MAGIC    OR T.month_number <> S.month_number
# MAGIC    OR T.month_name <> S.month_name
# MAGIC    OR T.quarter <> S.quarter
# MAGIC    OR T.year <> S.year
# MAGIC    OR T.is_weekend <> S.is_weekend;

# COMMAND ----------

# MAGIC %md
# MAGIC HCP DIMENSION

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Silver HCP table from the Bronze source
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.silver.slv_hcp
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC     npi_number,
# MAGIC     first_name,
# MAGIC     last_name,
# MAGIC     specialty,
# MAGIC     state_license_number,
# MAGIC     Load_Date
# MAGIC FROM life_sciences_analytics.bronze.src_hcp;

# COMMAND ----------

# MAGIC %sql
# MAGIC --Test 1: Record Count check
# MAGIC SELECT COUNT(*) AS SOURCE_COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_hcp;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS TARGET_COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_hcp;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 2: Record count with GROUP BY
# MAGIC SELECT specialty, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_hcp
# MAGIC GROUP BY specialty;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT specialty, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_hcp
# MAGIC GROUP BY specialty;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 3: Random Record Check
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_hcp
# MAGIC ORDER BY npi_number
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.silver.slv_hcp
# MAGIC ORDER BY npi_number
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 4: COLUMN LEVEL CHECK
# MAGIC SELECT COUNT(*) AS mismatch
# MAGIC FROM life_sciences_analytics.silver.slv_hcp T
# MAGIC LEFT JOIN life_sciences_analytics.bronze.src_hcp S
# MAGIC     ON T.npi_number = S.npi_number
# MAGIC WHERE S.npi_number IS NULL
# MAGIC    OR T.first_name <> S.first_name
# MAGIC    OR T.last_name <> S.last_name
# MAGIC    OR T.specialty <> S.specialty
# MAGIC    OR T.state_license_number <> S.state_license_number;

# COMMAND ----------

# MAGIC %md
# MAGIC HCO Dimension

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Silver HCO table from the Bronze source
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.silver.slv_hco
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC     facility_id,
# MAGIC     facility_name,
# MAGIC     facility_type,
# MAGIC     city,
# MAGIC     state,
# MAGIC     zip_code,
# MAGIC     Load_Date
# MAGIC FROM life_sciences_analytics.bronze.src_hco;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 1: Record Count Check
# MAGIC SELECT COUNT(*) AS SOURCE_COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_hco;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS TARGET_COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_hco;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 2: Record Count Check with GROUP BY
# MAGIC SELECT facility_type, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_hco
# MAGIC GROUP BY facility_type;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT facility_type, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_hco
# MAGIC GROUP BY facility_type;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 3: Random record Check
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_hco
# MAGIC ORDER BY facility_id
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.silver.slv_hco
# MAGIC ORDER BY facility_id
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 4: Column level Check
# MAGIC SELECT COUNT(*) AS mismatch
# MAGIC FROM life_sciences_analytics.silver.slv_hco T
# MAGIC LEFT JOIN life_sciences_analytics.bronze.src_hco S
# MAGIC     ON T.facility_id = S.facility_id
# MAGIC WHERE S.facility_id IS NULL
# MAGIC    OR T.facility_name <> S.facility_name
# MAGIC    OR T.facility_type <> S.facility_type
# MAGIC    OR T.city <> S.city
# MAGIC    OR T.state <> S.state
# MAGIC    OR T.zip_code <> S.zip_code;

# COMMAND ----------

# MAGIC %md
# MAGIC PRODUCT DIMENSION

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Silver Product table from the Bronze source
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.silver.slv_product
# MAGIC USING DELTA
# MAGIC AS
# MAGIC SELECT
# MAGIC     ndc_code,
# MAGIC     brand_name,
# MAGIC     dosage_form,
# MAGIC     strength,
# MAGIC     therapeutic_class,
# MAGIC     wac_price,
# MAGIC     Load_Date
# MAGIC FROM life_sciences_analytics.bronze.src_product;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 1: record count check
# MAGIC SELECT COUNT(*) AS SOURCE_COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_product;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS TARGET_COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_product;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 2: Record Count Check with GROUP BY
# MAGIC SELECT brand_name, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.bronze.src_product
# MAGIC GROUP BY brand_name;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT brand_name, COUNT(*) AS COUNT
# MAGIC FROM life_sciences_analytics.silver.slv_product
# MAGIC GROUP BY brand_name;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 3: Random record check
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_product
# MAGIC ORDER BY ndc_code
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.silver.slv_product
# MAGIC ORDER BY ndc_code
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC --TEST 4: Column Level Check
# MAGIC SELECT COUNT(*) AS mismatch
# MAGIC FROM life_sciences_analytics.silver.slv_product T
# MAGIC LEFT JOIN life_sciences_analytics.bronze.src_product S
# MAGIC     ON T.ndc_code = S.ndc_code
# MAGIC WHERE S.ndc_code IS NULL
# MAGIC    OR T.brand_name <> S.brand_name
# MAGIC    OR T.dosage_form <> S.dosage_form
# MAGIC    OR T.strength <> S.strength
# MAGIC    OR T.therapeutic_class <> S.therapeutic_class
# MAGIC    OR T.wac_price <> S.wac_price;