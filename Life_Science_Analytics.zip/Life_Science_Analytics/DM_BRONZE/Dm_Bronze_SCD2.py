# Databricks notebook source
# MAGIC %md
# MAGIC **Bronze Layer: Ingesting Raw Data**

# COMMAND ----------

# MAGIC %md
# MAGIC Sales Rep Dimension

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType
from pyspark.sql.functions import col, to_date, current_timestamp


# COMMAND ----------

# Step 1: Define source path
source_path = "/Volumes/life_sciences_analytics/bronze/source_files/"

# Step 2: Define schema
schema = StructType([
    StructField("rep_emp_id", StringType(), True),
    StructField("rep_name", StringType(), True),
    StructField("territory_code", StringType(), True),
    StructField("region", StringType(), True),
    StructField("role", StringType(), True),
    StructField("effective_date", StringType(), True)
])

# Step 3: Select CSV files starting with src_sales_rep
files = sorted([
    f for f in dbutils.fs.ls(source_path)
    if f.name.lower().startswith("src_sales_rep")
    and f.name.lower().endswith(".csv")
], key=lambda f: f.name.lower())


# COMMAND ----------

# Step 4: Process each file
for file in files:

    df = (
        spark.read
        .option("header", True)
        .schema(schema)
        .csv(file.path)
    )

    # Prepare records
    df = (
        df.withColumn(
            "effective_date",
            to_date(col("effective_date"), "yyyy-MM-dd")
        )
        .withColumn("Load_Date", current_timestamp())
        .dropDuplicates(["rep_emp_id", "effective_date"])
    )

    df.createOrReplaceTempView("sales_rep_incoming")


# COMMAND ----------

# Step 5: Upsert records into Bronze
spark.sql("""
        MERGE INTO life_sciences_analytics.bronze.src_sales_rep T
        USING sales_rep_incoming S
        ON  T.rep_emp_id = S.rep_emp_id
        AND T.effective_date = S.effective_date

        WHEN MATCHED AND NOT (
               T.rep_name <=> S.rep_name
           AND T.territory_code <=> S.territory_code
           AND T.region <=> S.region
           AND T.role <=> S.role
        )
        THEN UPDATE SET
            T.rep_name = S.rep_name,
            T.territory_code = S.territory_code,
            T.region = S.region,
            T.role = S.role,
            T.Load_Date = S.Load_Date

        WHEN NOT MATCHED THEN
            INSERT (
                rep_emp_id,
                rep_name,
                territory_code,
                region,
                role,
                effective_date,
                Load_Date
            )
            VALUES (
                S.rep_emp_id,
                S.rep_name,
                S.territory_code,
                S.region,
                S.role,
                S.effective_date,
                S.Load_Date
            )
    """)

print(f"Processed: {file.name}")

# COMMAND ----------

# Step 6: Verify Bronze
spark.sql("""
    SELECT
        COUNT(*) AS total_records,
        MAX(effective_date) AS latest_effective_date
    FROM life_sciences_analytics.bronze.src_sales_rep
""").show()