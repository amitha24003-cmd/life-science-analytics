# Databricks notebook source
#Importing necessary Functions
from pyspark.sql.types import (
    StructType, StructField, StringType,
    IntegerType, LongType, DateType,
    DecimalType
)
import pyspark.sql.functions as F

catalog_name = "life_sciences_analytics"

# COMMAND ----------

# MAGIC %md
# MAGIC Date Dimension

# COMMAND ----------

#defining Schema
calendar_schema = StructType([
    StructField("calendar_date", DateType(), True),
    StructField("day_of_week", IntegerType(), True),
    StructField("day_name", StringType(), True),
    StructField("month_number", IntegerType(), True),
    StructField("month_name", StringType(), True),
    StructField("quarter", StringType(), True),
    StructField("year", IntegerType(), True),
    StructField("is_weekend", StringType(), True)
])


# COMMAND ----------

#Defining source path
raw_data_path = (
    "/Volumes/life_sciences_analytics/"
    "bronze/source_files/src_calendar.csv"
)

df_raw = (
    spark.read
    .option("header", "true")
    .option("delimiter", ",")
    .schema(calendar_schema)
    .csv(raw_data_path)
)

# Add only the Load_Date column
df_raw = df_raw.withColumn(
    "Load_Date",
    F.current_timestamp()
)

display(df_raw.limit(5))

# COMMAND ----------

#Writing into bronze table
df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(
        f"{catalog_name}.bronze.src_calender"
    )

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_calender
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %md
# MAGIC HCP Dimension

# COMMAND ----------

# Define the schema for HCP source data
hcp_schema = StructType([
    StructField("npi_number", LongType(), True),
    StructField("first_name", StringType(), True),
    StructField("last_name", StringType(), True),
    StructField("specialty", StringType(), True),
    StructField("state_license_number", StringType(), True)
])

# COMMAND ----------

# Load HCP data using the defined schema
raw_data_path = "/Volumes/life_sciences_analytics/bronze/source_files/src_hcp.csv"

df_raw = (
    spark.read
    .option("header", "true")
    .option("delimiter", ",")
    .schema(hcp_schema)
    .csv(raw_data_path)
)

# Add the load timestamp
df_raw = df_raw.withColumn("Load_Date", F.current_timestamp())

# Display sample HCP records
display(df_raw.limit(5))

# COMMAND ----------

# Write HCP data to the Bronze Delta table
df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.src_hcp")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the HCP records
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_hcp
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %md
# MAGIC HCO Dimension

# COMMAND ----------

# Define the schema for HCO source data
hco_schema = StructType([
    StructField("facility_id", StringType(), True),
    StructField("facility_name", StringType(), True),
    StructField("facility_type", StringType(), True),
    StructField("city", StringType(), True),
    StructField("state", StringType(), True),
    StructField("zip_code", StringType(), True)
])

# COMMAND ----------

# Load HCO data using the defined schema
raw_data_path = "/Volumes/life_sciences_analytics/bronze/source_files/src_hco.csv"

df_raw = (
    spark.read
    .option("header", "true")
    .option("delimiter", ",")
    .schema(hco_schema)
    .csv(raw_data_path)
)

# Add the load timestamp
df_raw = df_raw.withColumn("Load_Date", F.current_timestamp())

# Display sample HCO records
display(df_raw.limit(5))

# COMMAND ----------

# Write HCO data to the Bronze Delta table
df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.src_hco")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the loaded HCO records
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_hco
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %md
# MAGIC Product Dimension

# COMMAND ----------

# Define the schema for Product source data
product_schema = StructType([
    StructField("ndc_code", StringType(), True),
    StructField("brand_name", StringType(), True),
    StructField("dosage_form", StringType(), True),
    StructField("strength", StringType(), True),
    StructField("therapeutic_class", StringType(), True),
    StructField("wac_price", DecimalType(12, 2), True)
])

# COMMAND ----------

# Load Product data using the defined schema
raw_data_path = "/Volumes/life_sciences_analytics/bronze/source_files/src_product.csv"

df_raw = (
    spark.read
    .option("header", "true")
    .option("delimiter", ",")
    .schema(product_schema)
    .csv(raw_data_path)
)

# Add the load timestamp
df_raw = df_raw.withColumn("Load_Date", F.current_timestamp())

# Display sample Product records
display(df_raw.limit(5))

# COMMAND ----------

# Write Product data to the Bronze Delta table
df_raw.write.format("delta") \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .saveAsTable(f"{catalog_name}.bronze.src_product")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify the loaded Product records
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.bronze.src_product
# MAGIC LIMIT 5;