# Databricks notebook source
# MAGIC %md
# MAGIC **GOLD LAYER: Business Ready data with SCD2 Implementation**

# COMMAND ----------

# Step 1: Inserting new records

spark.sql("""
INSERT INTO life_sciences_analytics.gold.Dim_Sales_Rep
(
    Rep_Employee_ID,
    Rep_Name,
    Territory_Code,
    Region,
    Role,
    Effective_Start_Date,
    Effective_End_Date,
    Is_Current_Flag,
    Load_Date
)
SELECT
    S.rep_emp_id,
    S.rep_name,
    S.territory_code,
    S.region,
    S.role,
    S.effective_date,
    '9999-12-31',
    'Y',
    CURRENT_TIMESTAMP()
FROM life_sciences_analytics.silver.slv_sales_rep S
LEFT ANTI JOIN life_sciences_analytics.gold.Dim_Sales_Rep T
    ON S.rep_emp_id = T.Rep_Employee_ID
   AND S.effective_date = T.Effective_Start_Date
""")



# COMMAND ----------

# Step 2: Inserting updated records

spark.sql("""
INSERT INTO life_sciences_analytics.gold.Dim_Sales_Rep
(
    Rep_Employee_ID,
    Rep_Name,
    Territory_Code,
    Region,
    Role,
    Effective_Start_Date,
    Effective_End_Date,
    Is_Current_Flag,
    Load_Date
)
SELECT
    S.rep_emp_id,
    S.rep_name,
    S.territory_code,
    S.region,
    S.role,
    S.effective_date,
    '9999-12-31',
    'Y',
    CURRENT_TIMESTAMP()
FROM life_sciences_analytics.silver.slv_sales_rep S
JOIN life_sciences_analytics.gold.Dim_Sales_Rep T
    ON S.rep_emp_id = T.Rep_Employee_ID
LEFT ANTI JOIN life_sciences_analytics.gold.Dim_Sales_Rep E
    ON S.rep_emp_id = E.Rep_Employee_ID
   AND S.effective_date = E.Effective_Start_Date
WHERE T.Is_Current_Flag = 'Y'
  AND S.effective_date > T.Effective_Start_Date
  AND NOT (
       S.territory_code <=> T.Territory_Code
   AND S.region <=> T.Region
   AND S.role <=> T.Role
  )
""")

# COMMAND ----------

# Step 3: Closing old records

spark.sql("""
MERGE INTO life_sciences_analytics.gold.Dim_Sales_Rep AS T
USING life_sciences_analytics.silver.slv_sales_rep AS S
ON T.Rep_Employee_ID = S.rep_emp_id
    AND T.Is_Current_Flag = 'Y'
    AND T.Effective_Start_Date < S.effective_date
    AND NOT (
        T.Territory_Code <=> S.territory_code
        AND T.Region <=> S.region
        AND T.Role <=> S.role
    )

WHEN MATCHED THEN
    UPDATE SET
        T.Effective_End_Date = DATE_SUB(S.effective_date, 1),
        T.Is_Current_Flag = 'N',
        T.Load_Date = CURRENT_TIMESTAMP()
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM life_sciences_analytics.gold.dim_sales_rep
# MAGIC     ORDER BY Rep_Employee_ID,Rep_Key;

# COMMAND ----------

# MAGIC %md
# MAGIC **SCD2 VALIDATION TESTS**

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 1: Check active records count
# MAGIC
# MAGIC SELECT
# MAGIC     SUM(CASE WHEN Is_Current_Flag = 'Y' THEN 1 ELSE 0 END)
# MAGIC         AS Active_Record_Count,
# MAGIC     COUNT(DISTINCT Rep_Employee_ID) AS Total_Employees
# MAGIC FROM life_sciences_analytics.gold.Dim_Sales_Rep;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 2: Verify latest source records are reflected in Gold
# MAGIC
# MAGIC -- TEST 2A: Display the latest source record for each employee
# MAGIC
# MAGIC SELECT S.*
# MAGIC FROM life_sciences_analytics.silver.slv_sales_rep S
# MAGIC JOIN (
# MAGIC     SELECT
# MAGIC         rep_emp_id,
# MAGIC         MAX(effective_date) AS latest_date
# MAGIC     FROM life_sciences_analytics.silver.slv_sales_rep
# MAGIC     GROUP BY rep_emp_id
# MAGIC ) L
# MAGIC     ON S.rep_emp_id = L.rep_emp_id
# MAGIC     AND S.effective_date = L.latest_date
# MAGIC ORDER BY S.rep_emp_id
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 2B: Display current records from the target table
# MAGIC
# MAGIC SELECT
# MAGIC     Rep_Employee_ID,
# MAGIC     Rep_Name,
# MAGIC     Territory_Code,
# MAGIC     Region,
# MAGIC     Role,
# MAGIC     Effective_Start_Date
# MAGIC FROM life_sciences_analytics.gold.Dim_Sales_Rep
# MAGIC WHERE Is_Current_Flag = 'Y'
# MAGIC ORDER BY Rep_Employee_ID
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST 3: Verify updated source records match target records
# MAGIC
# MAGIC SELECT
# MAGIC     S.rep_emp_id,
# MAGIC     S.territory_code AS Source_Territory,
# MAGIC     T.Territory_Code AS Target_Territory,
# MAGIC     S.region AS Source_Region,
# MAGIC     T.Region AS Target_Region
# MAGIC FROM life_sciences_analytics.silver.slv_sales_rep S
# MAGIC JOIN life_sciences_analytics.gold.Dim_Sales_Rep T
# MAGIC     ON S.rep_emp_id = T.Rep_Employee_ID
# MAGIC WHERE S.effective_date = (
# MAGIC     SELECT MAX(S2.effective_date)
# MAGIC     FROM life_sciences_analytics.silver.slv_sales_rep S2
# MAGIC     WHERE S2.rep_emp_id = S.rep_emp_id
# MAGIC )
# MAGIC AND T.Is_Current_Flag = 'Y'
# MAGIC AND (
# MAGIC     NOT (S.territory_code <=> T.Territory_Code)
# MAGIC     OR NOT (S.region <=> T.Region)
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST CASE 4: Check for duplicate active records
# MAGIC
# MAGIC SELECT
# MAGIC     Rep_Employee_ID,
# MAGIC     COUNT(*) AS Active_Count
# MAGIC FROM life_sciences_analytics.gold.Dim_Sales_Rep
# MAGIC WHERE Is_Current_Flag = 'Y'
# MAGIC GROUP BY Rep_Employee_ID
# MAGIC HAVING COUNT(*) > 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- TEST CASE 5: Validate active records have the expected end date
# MAGIC
# MAGIC SELECT *
# MAGIC FROM life_sciences_analytics.gold.Dim_Sales_Rep
# MAGIC WHERE Is_Current_Flag = 'Y'
# MAGIC   AND (
# MAGIC       Effective_End_Date IS NULL
# MAGIC       OR Effective_End_Date <> DATE '9999-12-31'
# MAGIC   );