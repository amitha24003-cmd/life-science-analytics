# Databricks notebook source
# MAGIC %md
# MAGIC GOLD LAYER: FINAL BUSINESS READY DIMENSION TABLES

# COMMAND ----------

# MAGIC %md
# MAGIC Date Dimension

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Gold Date dimension table
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.gold.Dim_Date (
# MAGIC     Date_Key INT NOT NULL,
# MAGIC     Calendar_Date DATE NOT NULL,
# MAGIC     Day_Of_Week INT,
# MAGIC     Day_Name STRING,
# MAGIC     Month_Number INT,
# MAGIC     Month_Name STRING,
# MAGIC     Quarter STRING,
# MAGIC     Year INT,
# MAGIC     Is_Weekend STRING,
# MAGIC     Load_Date TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert new calendar dates into the Gold Date dimension
# MAGIC MERGE INTO life_sciences_analytics.gold.Dim_Date AS tgt
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         CAST(date_format(calendar_date, 'yyyyMMdd') AS INT) AS Date_Key,
# MAGIC         calendar_date AS Calendar_Date,
# MAGIC         day_of_week AS Day_Of_Week,
# MAGIC         day_name AS Day_Name,
# MAGIC         month_number AS Month_Number,
# MAGIC         month_name AS Month_Name,
# MAGIC         quarter AS Quarter,
# MAGIC         year AS Year,
# MAGIC         is_weekend AS Is_Weekend,
# MAGIC         current_timestamp() AS Load_Date
# MAGIC     FROM life_sciences_analytics.silver.slv_calender
# MAGIC ) AS src
# MAGIC ON tgt.Calendar_Date = src.Calendar_Date
# MAGIC
# MAGIC WHEN NOT MATCHED THEN
# MAGIC     INSERT (
# MAGIC         Date_Key,
# MAGIC         Calendar_Date,
# MAGIC         Day_Of_Week,
# MAGIC         Day_Name,
# MAGIC         Month_Number,
# MAGIC         Month_Name,
# MAGIC         Quarter,
# MAGIC         Year,
# MAGIC         Is_Weekend,
# MAGIC         Load_Date
# MAGIC     )
# MAGIC     VALUES (
# MAGIC         src.Date_Key,
# MAGIC         src.Calendar_Date,
# MAGIC         src.Day_Of_Week,
# MAGIC         src.Day_Name,
# MAGIC         src.Month_Number,
# MAGIC         src.Month_Name,
# MAGIC         src.Quarter,
# MAGIC         src.Year,
# MAGIC         src.Is_Weekend,
# MAGIC         src.Load_Date
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS total_rows
# MAGIC FROM life_sciences_analytics.gold.Dim_Date;

# COMMAND ----------

# MAGIC %md
# MAGIC HCP Dimension

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Gold HCP dimension table
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.gold.Dim_HCP (
# MAGIC     HCP_Key BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC     NPI_Number BIGINT NOT NULL,
# MAGIC     First_Name STRING,
# MAGIC     Last_Name STRING,
# MAGIC     Specialty STRING,
# MAGIC     State_License_Number STRING,
# MAGIC     Load_Date TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert new HCP records without updating existing records
# MAGIC MERGE INTO life_sciences_analytics.gold.Dim_HCP AS tgt
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         npi_number AS NPI_Number,
# MAGIC         first_name AS First_Name,
# MAGIC         last_name AS Last_Name,
# MAGIC         specialty AS Specialty,
# MAGIC         state_license_number AS State_License_Number
# MAGIC     FROM life_sciences_analytics.silver.slv_hcp
# MAGIC ) AS src
# MAGIC ON tgt.NPI_Number = src.NPI_Number
# MAGIC
# MAGIC WHEN NOT MATCHED THEN
# MAGIC     INSERT (
# MAGIC         NPI_Number,
# MAGIC         First_Name,
# MAGIC         Last_Name,
# MAGIC         Specialty,
# MAGIC         State_License_Number,
# MAGIC         Load_Date
# MAGIC     )
# MAGIC     VALUES (
# MAGIC         src.NPI_Number,
# MAGIC         src.First_Name,
# MAGIC         src.Last_Name,
# MAGIC         src.Specialty,
# MAGIC         src.State_License_Number,
# MAGIC         CURRENT_TIMESTAMP()
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check the HCP dimension record count
# MAGIC SELECT COUNT(*) AS total_rows
# MAGIC FROM life_sciences_analytics.gold.Dim_HCP;

# COMMAND ----------

# MAGIC %md
# MAGIC HCO Dimension

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Gold HCO dimension table
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.gold.Dim_HCO (
# MAGIC     HCO_Key BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC     Facility_ID STRING NOT NULL,
# MAGIC     Facility_Name STRING,
# MAGIC     Facility_Type STRING,
# MAGIC     City STRING,
# MAGIC     State STRING,
# MAGIC     Zip_Code STRING,
# MAGIC     Load_Date TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert new HCO records without updating existing records
# MAGIC MERGE INTO life_sciences_analytics.gold.Dim_HCO AS tgt
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         facility_id AS Facility_ID,
# MAGIC         facility_name AS Facility_Name,
# MAGIC         facility_type AS Facility_Type,
# MAGIC         city AS City,
# MAGIC         state AS State,
# MAGIC         zip_code AS Zip_Code
# MAGIC     FROM life_sciences_analytics.silver.slv_hco
# MAGIC ) AS src
# MAGIC ON tgt.Facility_ID = src.Facility_ID
# MAGIC
# MAGIC WHEN NOT MATCHED THEN
# MAGIC     INSERT (
# MAGIC         Facility_ID,
# MAGIC         Facility_Name,
# MAGIC         Facility_Type,
# MAGIC         City,
# MAGIC         State,
# MAGIC         Zip_Code,
# MAGIC         Load_Date
# MAGIC     )
# MAGIC     VALUES (
# MAGIC         src.Facility_ID,
# MAGIC         src.Facility_Name,
# MAGIC         src.Facility_Type,
# MAGIC         src.City,
# MAGIC         src.State,
# MAGIC         src.Zip_Code,
# MAGIC         CURRENT_TIMESTAMP()
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check the HCO dimension record count
# MAGIC SELECT COUNT(*) AS total_rows
# MAGIC FROM life_sciences_analytics.gold.Dim_HCO;

# COMMAND ----------

# MAGIC %md
# MAGIC Product Dimension

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the Gold Product dimension table
# MAGIC CREATE TABLE IF NOT EXISTS life_sciences_analytics.gold.Dim_Product (
# MAGIC     Product_Key BIGINT GENERATED ALWAYS AS IDENTITY,
# MAGIC     NDC_Code STRING NOT NULL,
# MAGIC     Brand_Name STRING,
# MAGIC     Dosage_Form STRING,
# MAGIC     Strength STRING,
# MAGIC     Therapeutic_Class STRING,
# MAGIC     WAC_Price DECIMAL(12,2),
# MAGIC     Load_Date TIMESTAMP
# MAGIC )
# MAGIC USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Insert new products without updating existing records
# MAGIC MERGE INTO life_sciences_analytics.gold.Dim_Product AS tgt
# MAGIC USING (
# MAGIC     SELECT
# MAGIC         ndc_code AS NDC_Code,
# MAGIC         brand_name AS Brand_Name,
# MAGIC         dosage_form AS Dosage_Form,
# MAGIC         strength AS Strength,
# MAGIC         therapeutic_class AS Therapeutic_Class,
# MAGIC         wac_price AS WAC_Price
# MAGIC     FROM life_sciences_analytics.silver.slv_product
# MAGIC ) AS src
# MAGIC ON tgt.NDC_Code = src.NDC_Code
# MAGIC
# MAGIC WHEN NOT MATCHED THEN
# MAGIC     INSERT (
# MAGIC         NDC_Code,
# MAGIC         Brand_Name,
# MAGIC         Dosage_Form,
# MAGIC         Strength,
# MAGIC         Therapeutic_Class,
# MAGIC         WAC_Price,
# MAGIC         Load_Date
# MAGIC     )
# MAGIC     VALUES (
# MAGIC         src.NDC_Code,
# MAGIC         src.Brand_Name,
# MAGIC         src.Dosage_Form,
# MAGIC         src.Strength,
# MAGIC         src.Therapeutic_Class,
# MAGIC         src.WAC_Price,
# MAGIC         CURRENT_TIMESTAMP()
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Check the Product dimension record count
# MAGIC SELECT COUNT(*) AS total_rows
# MAGIC FROM life_sciences_analytics.gold.Dim_Product;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM life_sciences_analytics.gold.dim_product
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM life_sciences_analytics.gold.dim_date
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM life_sciences_analytics.gold.dim_hco
# MAGIC LIMIT 5;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM life_sciences_analytics.gold.dim_hcp
# MAGIC LIMIT 5;