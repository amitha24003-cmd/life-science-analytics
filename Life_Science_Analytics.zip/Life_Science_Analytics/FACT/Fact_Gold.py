# Databricks notebook source
# MAGIC %md
# MAGIC GOLD LAYER: BUSINESS READY FACT TABLE USING INCREMENTAL LOAD

# COMMAND ----------

# Step 1: Create Gold fact table

spark.sql("""
CREATE TABLE IF NOT EXISTS
life_sciences_analytics.gold.Fact_Daily_Commercial_Sales
(
    Date_Key INT,
    HCP_Key BIGINT,
    HCO_Key BIGINT,
    Product_Key BIGINT,
    Rep_Key BIGINT,
    Channel_Type STRING,
    TRx_Count INT,
    NRx_Count INT,
    Units_Dispensed INT,
    Gross_Sales_Amount DECIMAL(12,2),
    Rebate_Amount DECIMAL(12,2),
    Net_Sales_Amount DECIMAL(12,2),
    Load_Date TIMESTAMP
)
USING DELTA
""")

# COMMAND ----------

# Step 2: Truncate Stage table

spark.sql("""
TRUNCATE TABLE
life_sciences_analytics.staging.stg_daily_prescriptions
""")

# COMMAND ----------

spark.sql("""
INSERT INTO life_sciences_analytics.staging.stg_daily_prescriptions
SELECT *
FROM life_sciences_analytics.silver.slv_daily_prescriptions
WHERE trx_date > (
    SELECT MAX_CREATED_DATE
    FROM life_sciences_analytics.staging.ctrl_fact_daily_commercial_sales
    WHERE TABLE_ID = 'FACT_DAILY_COMMERCIAL_SALES'
)
OR trx_date  > (
    SELECT MAX_MODIFIED_DATE
    FROM life_sciences_analytics.staging.ctrl_fact_daily_commercial_sales
    WHERE TABLE_ID = 'FACT_DAILY_COMMERCIAL_SALES'
)
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS stage_count
# MAGIC FROM life_sciences_analytics.staging.stg_daily_prescriptions;

# COMMAND ----------

# Step 4: Stage to Gold - UPSERT

spark.sql("""
MERGE INTO
    life_sciences_analytics.gold.Fact_Daily_Commercial_Sales T

USING (
    SELECT
        X.Date_Key,
        X.HCP_Key,
        X.HCO_Key,
        X.Product_Key,
        X.Rep_Key,
        X.Channel_Type,
        X.TRx_Count,
        X.NRx_Count,
        X.Units_Dispensed,

        CAST(
            X.Gross_Sales_Amount
            AS DECIMAL(12,2)
        ) AS Gross_Sales_Amount,

        CAST(
            X.Gross_Sales_Amount * X.Rebate_Pct
            AS DECIMAL(12,2)
        ) AS Rebate_Amount,

        CAST(
            X.Gross_Sales_Amount
            - (X.Gross_Sales_Amount * X.Rebate_Pct)
            AS DECIMAL(12,2)
        ) AS Net_Sales_Amount

    FROM (
        SELECT
            D.Date_Key,
            H.HCP_Key,
            O.HCO_Key,
            P.Product_Key,
            R.Rep_Key,
            S.channel AS Channel_Type,
            S.trx_count AS TRx_Count,
            S.nrx_count AS NRx_Count,
            S.units_dispensed AS Units_Dispensed,
            S.rebate_pct AS Rebate_Pct,

            CAST(
                S.units_dispensed * P.WAC_Price
                AS DECIMAL(12,2)
            ) AS Gross_Sales_Amount

        FROM life_sciences_analytics.staging.stg_daily_prescriptions S

        JOIN life_sciences_analytics.gold.Dim_Date D
            ON S.trx_date = D.Calendar_Date

        JOIN life_sciences_analytics.gold.Dim_HCP H
            ON S.npi_number = H.NPI_Number

        JOIN life_sciences_analytics.gold.Dim_HCO O
            ON S.facility_id = O.Facility_ID

        JOIN life_sciences_analytics.gold.Dim_Product P
            ON S.ndc_code = P.NDC_Code

        JOIN life_sciences_analytics.gold.Dim_Sales_Rep R
            ON S.rep_emp_id = R.Rep_Employee_ID
           AND S.trx_date >= R.Effective_Start_Date
           AND (
                S.trx_date <= R.Effective_End_Date
                OR R.Effective_End_Date IS NULL
           )
    ) X
) S

ON  T.Date_Key = S.Date_Key
AND T.HCP_Key = S.HCP_Key
AND T.HCO_Key = S.HCO_Key
AND T.Product_Key = S.Product_Key
AND T.Rep_Key = S.Rep_Key
AND T.Channel_Type = S.Channel_Type

WHEN MATCHED AND NOT (
       T.TRx_Count <=> S.TRx_Count
   AND T.NRx_Count <=> S.NRx_Count
   AND T.Units_Dispensed <=> S.Units_Dispensed
   AND T.Gross_Sales_Amount <=> S.Gross_Sales_Amount
   AND T.Rebate_Amount <=> S.Rebate_Amount
   AND T.Net_Sales_Amount <=> S.Net_Sales_Amount
)
THEN UPDATE SET
    T.TRx_Count = S.TRx_Count,
    T.NRx_Count = S.NRx_Count,
    T.Units_Dispensed = S.Units_Dispensed,
    T.Gross_Sales_Amount = S.Gross_Sales_Amount,
    T.Rebate_Amount = S.Rebate_Amount,
    T.Net_Sales_Amount = S.Net_Sales_Amount,
    T.Load_Date = CURRENT_TIMESTAMP()

WHEN NOT MATCHED THEN
    INSERT (
        Date_Key,
        HCP_Key,
        HCO_Key,
        Product_Key,
        Rep_Key,
        Channel_Type,
        TRx_Count,
        NRx_Count,
        Units_Dispensed,
        Gross_Sales_Amount,
        Rebate_Amount,
        Net_Sales_Amount,
        Load_Date
    )
    VALUES (
        S.Date_Key,
        S.HCP_Key,
        S.HCO_Key,
        S.Product_Key,
        S.Rep_Key,
        S.Channel_Type,
        S.TRx_Count,
        S.NRx_Count,
        S.Units_Dispensed,
        S.Gross_Sales_Amount,
        S.Rebate_Amount,
        S.Net_Sales_Amount,
        CURRENT_TIMESTAMP()
    )
""")

# COMMAND ----------



# Step 5: Referential Integrity Validation

spark.sql("""
SELECT COUNT(*) AS Orphan_Count
FROM life_sciences_analytics.gold.Fact_Daily_Commercial_Sales F

LEFT JOIN life_sciences_analytics.gold.Dim_Date D
    ON F.Date_Key = D.Date_Key
LEFT JOIN life_sciences_analytics.gold.Dim_HCP H
    ON F.HCP_Key = H.HCP_Key
LEFT JOIN life_sciences_analytics.gold.Dim_HCO O
    ON F.HCO_Key = O.HCO_Key
LEFT JOIN life_sciences_analytics.gold.Dim_Product P
    ON F.Product_Key = P.Product_Key
LEFT JOIN life_sciences_analytics.gold.Dim_Sales_Rep R
    ON F.Rep_Key = R.Rep_Key

WHERE D.Date_Key IS NULL
   OR H.HCP_Key IS NULL
   OR O.HCO_Key IS NULL
   OR P.Product_Key IS NULL
   OR R.Rep_Key IS NULL
""").show()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     trx_date,
# MAGIC     SUM(trx_count) AS total_trx,
# MAGIC     SUM(nrx_count) AS total_nrx
# MAGIC FROM life_sciences_analytics.bronze.src_daily_prescriptions
# MAGIC GROUP BY trx_date
# MAGIC ORDER BY trx_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     Date_Key,
# MAGIC     SUM(trx_count) AS total_trx,
# MAGIC     SUM(nrx_count) AS total_nrx
# MAGIC FROM life_sciences_analytics.gold.fact_daily_commercial_sales
# MAGIC GROUP BY Date_Key
# MAGIC ORDER BY Date_Key;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM life_sciences_analytics.gold.fact_daily_commercial_sales;

# COMMAND ----------

# Step 6: Update Control Table

spark.sql("""
UPDATE life_sciences_analytics.staging.ctrl_fact_daily_commercial_sales
SET
    MAX_CREATED_DATE = (
        SELECT CAST(MAX(trx_date) AS TIMESTAMP)
        FROM life_sciences_analytics.staging.stg_daily_prescriptions
    ),
    MAX_MODIFIED_DATE = (
        SELECT MAX(Load_Date)
        FROM life_sciences_analytics.staging.stg_daily_prescriptions
    )
WHERE TABLE_ID = 'FACT_DAILY_COMMERCIAL_SALES'
""")