# Databricks notebook source
# MAGIC %md
# MAGIC Bronze Layer: Raw data ingestion

# COMMAND ----------

from pyspark.sql.types import (
    StructType, StructField, StringType,
    IntegerType, DecimalType
)
from pyspark.sql.functions import col, to_date, current_timestamp

# Define schema
schema = StructType([
    StructField("trx_date", StringType(), True),
    StructField("npi_number", StringType(), True),
    StructField("facility_id", StringType(), True),
    StructField("ndc_code", StringType(), True),
    StructField("rep_emp_id", StringType(), True),
    StructField("channel", StringType(), True),
    StructField("trx_count", IntegerType(), True),
    StructField("nrx_count", IntegerType(), True),
    StructField("units_dispensed", IntegerType(), True),
    StructField("rebate_pct", DecimalType(5, 2), True)
])

# COMMAND ----------

# Create Bronze fact table

spark.sql("""
CREATE TABLE IF NOT EXISTS
life_sciences_analytics.bronze.src_daily_prescriptions
(
    trx_date DATE,
    npi_number STRING,
    facility_id STRING,
    ndc_code STRING,
    rep_emp_id STRING,
    channel STRING,
    trx_count INT,
    nrx_count INT,
    units_dispensed INT,
    rebate_pct DECIMAL(5,2),
    Load_Date TIMESTAMP
)
USING DELTA
""")

# COMMAND ----------

# Select CSV files starting with src_daily_prescriptions

source_path = "/Volumes/life_sciences_analytics/bronze/source_files/"

files = sorted([
    f.path for f in dbutils.fs.ls(source_path)
    if f.name.lower().startswith("src_daily_prescriptions")
    and f.name.lower().endswith(".csv")
])

if not files:
    raise ValueError("No matching prescription CSV files found.")

# Read all matching files together
df = (
    spark.read
    .option("header", True)
    .schema(schema)
    .csv(files)
)

print("Files found:", len(files))
print("Records read:", df.count())

# COMMAND ----------

# Convert date and add Load_Date

df = (
    df.withColumn(
        "trx_date",
        to_date(col("trx_date"), "yyyy-MM-dd")
    )
    .withColumn("Load_Date", current_timestamp())
)

df.createOrReplaceTempView("fact_incoming")

# COMMAND ----------

# Upsert records into Bronze

spark.sql("""
MERGE INTO
    life_sciences_analytics.bronze.src_daily_prescriptions T
USING fact_incoming S
ON  T.trx_date = S.trx_date
AND T.npi_number = S.npi_number
AND T.facility_id = S.facility_id
AND T.ndc_code = S.ndc_code
AND T.rep_emp_id = S.rep_emp_id
AND T.channel = S.channel

WHEN MATCHED AND NOT (
       T.trx_count <=> S.trx_count
   AND T.nrx_count <=> S.nrx_count
   AND T.units_dispensed <=> S.units_dispensed
   AND T.rebate_pct <=> S.rebate_pct
)
THEN UPDATE SET
    T.trx_count = S.trx_count,
    T.nrx_count = S.nrx_count,
    T.units_dispensed = S.units_dispensed,
    T.rebate_pct = S.rebate_pct,
    T.Load_Date = CURRENT_TIMESTAMP()

WHEN NOT MATCHED THEN
    INSERT (
        trx_date,
        npi_number,
        facility_id,
        ndc_code,
        rep_emp_id,
        channel,
        trx_count,
        nrx_count,
        units_dispensed,
        rebate_pct,
        Load_Date
    )
    VALUES (
        S.trx_date,
        S.npi_number,
        S.facility_id,
        S.ndc_code,
        S.rep_emp_id,
        S.channel,
        S.trx_count,
        S.nrx_count,
        S.units_dispensed,
        S.rebate_pct,
        S.Load_Date
    )
""")

# COMMAND ----------

# Verify record counts by transaction date

spark.sql("""
SELECT
    trx_date,
    COUNT(*) AS record_count
FROM life_sciences_analytics.bronze.src_daily_prescriptions
GROUP BY trx_date
ORDER BY trx_date
""").show()

# COMMAND ----------

# Verify total Bronze records

spark.sql("""
SELECT
    COUNT(*) AS total_records,
    MIN(trx_date) AS first_date,
    MAX(trx_date) AS last_date
FROM life_sciences_analytics.bronze.src_daily_prescriptions
""").show()