# Databricks notebook source
# MAGIC %md
# MAGIC Silver Layer: Data Validation

# COMMAND ----------

# Step 1: Create Silver fact table

spark.sql("""
CREATE TABLE IF NOT EXISTS
life_sciences_analytics.silver.slv_daily_prescriptions
(
    trx_date DATE,
    npi_number STRING,
    facility_id STRING,
    ndc_code STRING,
    rep_emp_id STRING,
    channel STRING,
    trx_count INT,
    nrx_count INT,
    units_dispensed INT,
    rebate_pct DECIMAL(5,2),
    Load_Date TIMESTAMP
)
USING DELTA
""")

# COMMAND ----------

# Step 2: Upsert records into Silver

spark.sql("""
MERGE INTO
    life_sciences_analytics.silver.slv_daily_prescriptions T
USING
    life_sciences_analytics.bronze.src_daily_prescriptions S
ON  T.trx_date = S.trx_date
AND T.npi_number = S.npi_number
AND T.facility_id = S.facility_id
AND T.ndc_code = S.ndc_code
AND T.rep_emp_id = S.rep_emp_id
AND T.channel = S.channel

WHEN MATCHED AND NOT (
       T.trx_count <=> S.trx_count
   AND T.nrx_count <=> S.nrx_count
   AND T.units_dispensed <=> S.units_dispensed
   AND T.rebate_pct <=> S.rebate_pct
)
THEN UPDATE SET
    T.trx_count = S.trx_count,
    T.nrx_count = S.nrx_count,
    T.units_dispensed = S.units_dispensed,
    T.rebate_pct = S.rebate_pct,
    T.Load_Date = CURRENT_TIMESTAMP()

WHEN NOT MATCHED THEN
    INSERT (
        trx_date,
        npi_number,
        facility_id,
        ndc_code,
        rep_emp_id,
        channel,
        trx_count,
        nrx_count,
        units_dispensed,
        rebate_pct,
        Load_Date
    )
    VALUES (
        S.trx_date,
        S.npi_number,
        S.facility_id,
        S.ndc_code,
        S.rep_emp_id,
        S.channel,
        S.trx_count,
        S.nrx_count,
        S.units_dispensed,
        S.rebate_pct,
        CURRENT_TIMESTAMP()
    )
""")

# COMMAND ----------

# Step 3: Verify Silver records

spark.sql("""
SELECT
    trx_date,
    COUNT(*) AS record_count
FROM life_sciences_analytics.silver.slv_daily_prescriptions
GROUP BY trx_date
ORDER BY trx_date
""").show()

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Test 1: Stratification test
# MAGIC SELECT
# MAGIC     trx_date,
# MAGIC     SUM(trx_count) AS total_trx,
# MAGIC     SUM(nrx_count) AS total_nrx
# MAGIC FROM life_sciences_analytics.bronze.src_daily_prescriptions
# MAGIC GROUP BY trx_date
# MAGIC ORDER BY trx_date;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     trx_date,
# MAGIC     SUM(trx_count) AS total_trx,
# MAGIC     SUM(nrx_count) AS total_nrx
# MAGIC FROM life_sciences_analytics.silver.slv_daily_prescriptions
# MAGIC GROUP BY trx_date
# MAGIC ORDER BY trx_date;