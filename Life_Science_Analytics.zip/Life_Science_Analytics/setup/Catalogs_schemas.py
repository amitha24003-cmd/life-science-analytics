# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE CATALOG IF NOT EXISTS life_sciences_analytics;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS life_sciences_analytics.bronze;
# MAGIC CREATE SCHEMA IF NOT EXISTS life_sciences_analytics.staging;
# MAGIC CREATE SCHEMA IF NOT EXISTS life_sciences_analytics.silver;
# MAGIC CREATE SCHEMA IF NOT EXISTS life_sciences_analytics.gold;